﻿using System.Windows.Controls;

namespace GerenCadastros {
    class Item {

        #region Vars

        public string Codigo { get; private set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }

        #endregion

        #region Constructors
        //public Item() {}

        public Item(string Cod) {
            Codigo = Cod;
        }

        #endregion

        #region Logical Functions

        #endregion

    }
}
