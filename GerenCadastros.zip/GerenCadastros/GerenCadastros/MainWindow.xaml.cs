﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace GerenCadastros {
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
            Cadastros = new List<Item>();
        }

        #region Vars

        private List<Item> Cadastros;
        private bool EditMode=false;
        private string OldCode;

        #endregion

        #region Buttons Functions

        private void BtnAS_Click(object sender, RoutedEventArgs e) {
            if (BtnAS.Content.ToString() == "Adicionar") {
                TxCod.IsEnabled = true;
                TxCod.Text = "";
                TxName.IsEnabled = true;
                TxName.Text = "";
                TxDesc.IsEnabled = true;
                TxDesc.Text = "";
                BtnCan.IsEnabled = true;
                BtnAS.Content = "Salvar";
                LvCad.SelectedIndex = -1;
                LvCad.IsEnabled = false;
            } else {
                if ((!String.IsNullOrWhiteSpace(TxCod.Text.ToString())) && (!String.IsNullOrWhiteSpace(TxName.Text.ToString()))) {
                    Item It = new Item(TxCod.Text.ToString()) {
                        Nome = TxName.Text.ToString(),
                        Descricao = TxDesc.Text.ToString()
                    };
                    if ((!Cadastros.Any(x=>x.Codigo==It.Codigo))||(EditMode==true)) {
                        TxCod.IsEnabled = false;
                        TxCod.Text = "";
                        TxName.IsEnabled = false;
                        TxName.Text = "";
                        TxDesc.IsEnabled = false;
                        TxDesc.Text = "";
                        BtnCan.IsEnabled = false;
                        BtnAS.Content = "Adicionar";
                        LvCad.IsEnabled = true;

                        if (EditMode == true) {
                            Cadastros = Cadastros.Where(x => x.Codigo != OldCode).ToList();
                        }
                        Cadastros.Add(It);
                        LvCadUpdate();
                        It = null;
                    } else {
                        MessageBox.Show("Codigo de Item ja Utilizado", "Aviso Duplicacao");
                    }
                }

            }
        }

        private void BtnCan_Click(object sender, RoutedEventArgs e) {
            TxCod.IsEnabled = false;
            TxCod.Text = "";
            TxName.IsEnabled = false;
            TxName.Text = "";
            TxDesc.IsEnabled = false;
            TxDesc.Text = "";
            BtnCan.IsEnabled = false;
            BtnAS.Content = "Adicionar";
            LvCad.IsEnabled = true;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e) {
            EditMode = true;
            OldCode = LvCad.SelectedValue.ToString();

            LvCad.SelectedIndex = -1;
            LvCad.IsEnabled = false;
            BtnCan.IsEnabled = true;
            BtnAS.Content = "Salvar";
            TxCod.IsEnabled = true;
            TxName.IsEnabled = true;
            TxDesc.IsEnabled = true;
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e) {
            try {
                if (MessageBox.Show("Certeza que deseja excluir o Item:\n" + LvCad.SelectedValue + " | " + TxName.Text.ToString() +" ?","Aviso",MessageBoxButton.YesNo)==MessageBoxResult.Yes){
                    Cadastros = Cadastros.Where(x => x.Codigo != LvCad.SelectedValue.ToString()).ToList();
                    LvCadUpdate();
                }
            } catch {

            }
        }

        #endregion

        #region Interface Functions

        private void LvCadUpdate() {
            Cadastros = Cadastros.OrderBy(x => x.Codigo).ToList();
            LvCad.ItemsSource = null;
            LvCad.ItemsSource = Cadastros;
            LvCad.SelectedIndex = -1;
        }

        private void LvCad_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) {
            try {
                Item It = Cadastros.First(x => x.Codigo == LvCad.SelectedValue.ToString());
                TxCod.Text = It.Codigo;
                TxName.Text = It.Nome;
                TxDesc.Text = It.Descricao;

                BtnEdit.IsEnabled = true;
                BtnDel.IsEnabled = true;

                //MessageBox.Show(LvCad.SelectedValue.ToString(), "Teste");
            } catch (Exception) {
                BtnEdit.IsEnabled = false;
                BtnDel.IsEnabled = false;
            }
        }

        #endregion

        #region Logical Functions

        #endregion
    }
}
